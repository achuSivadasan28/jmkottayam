<?php
date_default_timezone_set('Asia/Kolkata');
$days=date('Y-m-d');
echo $days;
?>