<?php
class Dbconn
{
    public static function con()
    {
      $connect=mysqli_connect("localhost:3306","millet_store_phy","_Ums5600h","db_millet_store_phy");
        if(!$connect)
        {
            die("connection error".mysqli_connect_error());
        }
        return $connect;
    }
    
    
}
?>