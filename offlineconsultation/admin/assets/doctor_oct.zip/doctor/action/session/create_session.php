<?php
session_start();
$_SESSION['doctor_login_id'] = 5;
$_SESSION['doctor_role'] = 'doctor';
$_SESSION['doctor_unique_code'] = '123';
$_SESSION['api_key_value_doctor'] = 'esight123456123';
?>