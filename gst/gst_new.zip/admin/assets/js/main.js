
// sidemenu 
$('.navBarBox').click(function(){
	$('.sidemenu').toggleClass('sidemenuFullActive');
	$('.navBarBox').toggleClass('navBarBoxActive');
	$('.canvas').toggleClass('canvasActive');
})