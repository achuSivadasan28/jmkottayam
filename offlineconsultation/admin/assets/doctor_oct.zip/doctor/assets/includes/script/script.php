
    <!-- jquery  -->
    <script src="assets/js/jquery.js"></script>
    <!-- fontawesome -->
    <script src="https://kit.fontawesome.com/4022a59704.js" crossorigin="anonymous"></script>
    <!-- spotlight  -->
    <script src="assets/js/spotlight.js"></script>
    <!-- text eiter -->
    <script src="assets/js/summernote-lite.js"></script>
    <!-- main -->
    <script src="assets/js/main.js"></script>