<?php
session_start();
date_default_timezone_set( 'Asia/Kolkata' );
$date = date( 'd-m-Y' );
$time = date( 'h:i:s A' );
include_once '../../../_class/query.php';
$obj = new query();
$file_name = $_POST['file_name'];
$appointment_id = $_POST['appointment_id'];
$file = $_POST['file'];
$branch = $_POST['branch_id'];
require_once '../../../_class_branch/query_branch.php';
$obj_branch = new query_branch();
$patient_id = 0;
$real_branch_id = 0;
$select_patient_id = $obj->selectData("patient_id,real_branch_id,branch_id","tbl_appointment","where id=$appointment_id");
if(mysqli_num_rows($select_patient_id)){
	$select_patient_id_row = mysqli_fetch_array($select_patient_id);
	$patient_id = $select_patient_id_row['patient_id'];
	$real_branch_id = $select_patient_id_row['real_branch_id'];
	$branch_id = $select_patient_id_row['branch_id'];
	if($real_branch_id == $branch_id){
	$info_data = array(
	"appointment_id" => $appointment_id,
	"patient_id" => $patient_id,
	"test_name" => $file_name,
	"lab_report_file" => $file,
	"lab_report_status" => 1,
	"added_date" => $date,
	"added_time" => $time,
	"status" => 1
);
$obj_branch->insertData("tbl_add_lab_data",$info_data);
//tbl_lab_report
$count = count($_FILES['files']['name']);
$main_folder_path = '';
if($branch == 4){
	$main_folder_path = "https://jmwell.in/offlineconsultation/";
	//$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_edy1/offlineconsultation/";
}else if($branch == 5){
	$main_folder_path = "https://pala.jmwell.in/offlineconsultation/";
	//$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala1/offlineconsultation/";
}else if($branch == 7){
	$main_folder_path = "https://kannur.jmwell.in/offlineconsultation/";
	//$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($branch == 8){
	$main_folder_path = "https://trvl.jmwell.in/offlineconsultation/";
	//$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($branch == 9){
	$main_folder_path = "https://tvm.jmwell.in/offlineconsultation/";
	//$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}
$upload_dir = "../../../lab/assets/fileupload/";
for($x=0; $x<$count;$x++)
{
    $filename=$_FILES['files']['name'][$x];

    //get extenshion
    $ext = pathinfo($filename,PATHINFO_EXTENSION);

    //vald image extenshion
	
    $valid_ext = array("jpg","jpeg","png");
	$path=$upload_dir.$filename;
    if(in_array($ext,$valid_ext))
    {
        // echo "haii";
        
        compressFile($_FILES['files']['tmp_name'][$x],$path,55);
        // echo $data;
        echo $patient_id;
    }else{
	insertnormal($_FILES['files']['tmp_name'][$x],$_FILES['files']['name'][$x],$upload_dir);
		echo $patient_id;
	}
}
	
}else{
		$select_patient_id_data = $obj_branch->selectData("id","tbl_appointment","where cross_appointment_id=$appointment_id and cross_branch_status=1");
		if(mysqli_num_rows($select_patient_id_data)>0){
			$select_patient_id_data_row = mysqli_fetch_array($select_patient_id_data);
			$appointment_id = $select_patient_id_data_row['id'];
		}
	$info_data = array(
	"appointment_id" => $appointment_id,
	"patient_id" => $patient_id,
	"test_name" => $file_name,
	"lab_report_file" => $file,
	"lab_report_status" => 1,
	"added_date" => $date,
	"added_time" => $time,
	"status" => 1
);
$obj_branch->insertData("tbl_add_lab_data",$info_data);
//tbl_lab_report
$count = count($_FILES['files']['name']);
$main_folder_path = '';
$main_folder_path_R = '';
$select_main_branch_url = $obj->selectData("branch_id,url","tbl_branch_url","where status!=0 and branch_id=$branch");
if(mysqli_num_rows($select_main_branch_url)>0){
	$select_main_branch_url_row = mysqli_fetch_array($select_main_branch_url);
	$main_folder_path = $select_main_branch_url_row['url'];
}
		
$select_folder_branch_url = $obj->selectData("branch_id,url","tbl_branch_url","where status!=0 and branch_id=$branch");
if(mysqli_num_rows($select_folder_branch_url)>0){
	$select_folder_branch_url_row = mysqli_fetch_array($select_folder_branch_url);
	$main_folder_path_R = $select_folder_branch_url_row['url'];
}
		/**
if($branch == 4){
	//$main_folder_path = "https://jmwell.in/offlineconsultation/";
	$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_edy/offlineconsultation/";
}else if($branch == 5){
	//$main_folder_path = "https://pala.jmwell.in/offlineconsultation/";
	$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($branch == 7){
	//$main_folder_path = "https://kannur.jmwell.in/offlineconsultation/";
	$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($branch == 8){
	//$main_folder_path = "https://trvl.jmwell.in/offlineconsultation/";
	$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($branch == 9){
	//$main_folder_path = "https://tvm.jmwell.in/offlineconsultation/";
	$main_folder_path = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}
$main_folder_path_R = 0;
if($real_branch_id == 4){
	$main_folder_path_R = "https://jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_edy/offlineconsultation/";
}else if($real_branch_id == 5){
	$main_folder_path_R = "https://pala.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($real_branch_id == 7){
	$main_folder_path_R = "https://kannur.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($real_branch_id == 8){
	$main_folder_path_R = "https://trvl.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}else if($real_branch_id == 9){
	$main_folder_path_R = "https://tvm.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}
else if($real_branch_id == 10){
	$main_folder_path_R = "https://blr.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}
else if($real_branch_id == 11){
	$main_folder_path_R = "https://kottakkal.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}
else if($real_branch_id == 12){
	$main_folder_path_R = "https://kkz.jmwell.in/offlineconsultation/";
	//$main_folder_path_R = "https://esightsolutions.in/jmwell_cross_branch/jmwell_pala/offlineconsultation/";
}**/
$upload_dir = "../../../lab/assets/fileupload/";
$upload_dir1 =  $main_folder_path_R."/lab/assets/fileupload/";
for($x=0; $x<$count;$x++)
{
    $filename=$_FILES['files']['name'][$x];

    //get extenshion
    $ext = pathinfo($filename,PATHINFO_EXTENSION);

    //vald image extenshion
	
    $valid_ext = array("jpg","jpeg","png");
	$path=$upload_dir.$filename;
	$path1=$upload_dir1.$filename;
    if(in_array($ext,$valid_ext))
    {
        // echo "haii";
        
        compressFile($_FILES['files']['tmp_name'][$x],$path,55);
		
        compressFile($_FILES['files']['tmp_name'][$x],$path1,55);
        // echo $data;
        echo $patient_id;
    }else{
	insertnormal($_FILES['files']['tmp_name'][$x],$_FILES['files']['name'][$x],$upload_dir);
	insertnormal1($_FILES['files']['tmp_name'][$x],$_FILES['files']['name'][$x],$upload_dir1);
		echo $patient_id;
	}
}
	}
}

function compressFile($source,$destination,$quaity)
{
	//echo "destination ".$destination." , ";
    $info = getimagesize($source);
    if($info['mime'] == 'image/jpeg')
        $image = imagecreatefromjpeg($source);
    elseif($info['mime'] == 'image/gif')
        $image = imagecreatefromgif($source);
    elseif($info['mime'] == 'image/png')
        $image = imagecreatefrompng($source);

    imagejpeg($image , $destination , $quaity);
    //echo $image;
}
function insertnormal($x,$y,$path)
{
	//echo $path;exit();
    move_uploaded_file($x,$path.$y);
}
function insertnormal1($x,$y,$path)
{
    move_uploaded_file($x,$path.$y);
}
?>