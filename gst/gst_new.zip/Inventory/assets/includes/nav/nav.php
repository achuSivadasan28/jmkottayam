
<div class="nav">
    <div class="container">
        <a href="index.php" class="navLogo">
            <img src="assets/images/johnmariansLogo.png" alt="">
        </a>
        <div class="navBar">
            <div class="navBarBox">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
        <div class="navProfile">
            <div class="navProfileBox">
                <div class="navProfileThumbnail">
                    <img src="assets/images/doctorAvatar.png" alt="">
                </div>
                <div class="navProfileName">
                    <p></p>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</div>